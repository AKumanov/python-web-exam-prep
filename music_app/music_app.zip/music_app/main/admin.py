from django.contrib import admin
from .models import Profile, Album

admin.site.register(Profile)
admin.site.register(Album)